const getToken = () => {
    return localStorage.getItem("tokenKey")
}

export default getToken