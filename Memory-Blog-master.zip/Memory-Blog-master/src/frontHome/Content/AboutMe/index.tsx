import './index.sass'
import ChatBox from "../../../components/ChatBox.tsx";

const AboutMe = () => {
    return <>
        <div className="AboutContainer">
            <ChatBox />
        </div>
    </>
}

export default AboutMe