import './index.css'
const SettingButton = () => {
    return <>
        <button className="setting-btn">
            <span className="bar bar1"></span>
            <span className="bar bar2"></span>
            <span className="bar bar1"></span>
        </button>
    </>
}

export default SettingButton