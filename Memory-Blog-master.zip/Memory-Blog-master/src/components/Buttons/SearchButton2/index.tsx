import './index.sass'
const SearchButton2 = () => {
    return <>
            <button className="SearchButton_home">
                <span className="span">🔎</span>
            </button>
    </>
}

export default SearchButton2