export interface SocialType{
    socialGithub: string;
    socialEmail: string;
    socialBilibili: string;
    socialQQ: string;
    socialNeteaseCloud: string;
}