export interface ViteEnv{
    readonly VITE_HTTP_BASEURL: string
    readonly VITE_CHAT_GPT_TOKEN: String
}