declare module '../assets/botui.js';
