export interface ImgUrl {
    imageKey: number
    imageUrl: string
}