export default interface UserData {
    username: string;
    password: string;
}