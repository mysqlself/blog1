export interface Friend {
    friendKey: number,
    siteName: string;
    avatar: string;
    siteUrl: string;
    description: string;
    status: number
}