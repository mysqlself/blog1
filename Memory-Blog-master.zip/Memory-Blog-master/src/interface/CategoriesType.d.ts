export interface CategoriesType {
    categoryKey: string | undefined;
    key: number;
    categoryTitle: string;
    pathName: string;
    introduce: string;
    icon: string;
    noteCount: number;
    color: string;
}